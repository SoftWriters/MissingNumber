﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ts_Upload(object sender, EventArgs e)
        {
            if (ts_Uploader.HasFile)
            {
                try
                {
                    
                    StreamReader m_Reader = new StreamReader(ts_Uploader.PostedFile.InputStream);
                    string m_Content = m_Reader.ReadToEnd();
                    string[] m_lines = m_Content.Split(new string[] { "\n", "\r\n" }, StringSplitOptions.RemoveEmptyEntries);
                    ArrayList m_MissingNumbers = new ArrayList();
                    foreach (string m_line in m_lines)
                    {
                        int[] m_IntArray = m_line.Split(',').Select(n => Convert.ToInt32(n)).ToArray();
                        var m_Numbers = m_IntArray;
                        var m_Range = Enumerable.Range(m_Numbers.Min(), (m_Numbers.Length + 1));
                        var m_Missing = m_Range.Except(m_Numbers);
                        m_MissingNumbers.Add(m_Missing.First().ToString());
                    }
                    MissingRepeater.DataSource = m_MissingNumbers;
                    MissingRepeater.DataBind();
                    //ts_Label.Text = "The missing number was " + m_Missing.First().ToString();
                }
                catch (Exception ex)
                {
                    ts_Error.Text = "The file could not be uploaded and checked. There was an error with proccessing the file: " + ex.Message ;
                }
            }
            else
            {
                ts_Error.Text = "There was no file selected to upload";
            }
        }

    }
}